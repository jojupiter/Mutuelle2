<?php

Yii::setAlias('@imageurl', 'http://localhost/advanced/backend/web');
return [
    
];
