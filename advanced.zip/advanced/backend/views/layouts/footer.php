<?php

/* @var $this View */
/* @var $content string */

use yii\web\View;

?>
<footer class="main-footer">
    <strong>Copyright &copy; 2014-<?php echo date("Y"); ?>&nbsp;<a href="http://polytechnique.cm">My Application</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0
    </div>
</footer>